import 'package:flutter/material.dart';
import 'package:myskincaremate_1/settingsTabPage.dart';
import 'appTheme.dart';
import 'homeTabPage.dart';
import 'listTabPage.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Skincare Mate',
      theme: ThemeData(
        // 기본 배경 흰색
        scaffoldBackgroundColor: Colors.white,
        // 기본 색상 팔레트, 연녹색
        primaryColor: AppTheme.c_sprout,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppTheme.c_sprout,
          secondary: AppTheme.c_opal, // accentColor 역할
        ),
        // 버튼, 카드 등 모서리를 둥글게(10px) 설정
        cardTheme: const CardTheme(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
          ),
        ),
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _index = 0; // 페이지 인덱스 0,1,2

  // 탭별로 보여줄 appBar 리스트
  final List<PreferredSizeWidget> _appBars = [
    // 홈 탭용 앱바
    AppBar(
      backgroundColor: AppTheme.c_sprout,
      title: Text(
        'MY SKINCARE MATE',
        style: TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
      ),
      centerTitle: true, // 앱바 텍스트 가운데 정렬
      foregroundColor: AppTheme.c_seawood,
    ),
    // 목록 탭용 앱바
    AppBar(
      backgroundColor: Colors.white,
      title: Text(
        '등록된 제품',
        style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
      ),
      foregroundColor: AppTheme.c_seawood,
    ),
    // 설정 탭용 앱바
    AppBar(
      backgroundColor: Colors.white,
      title: Text(
        '설정',
        style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
      ),
      foregroundColor: AppTheme.c_seawood,
    ),
  ];

  // 탭별로 보여줄 화면
  final List<Widget> _pages = <Widget>[
    // 홈 탭 화면
    HomeTabPage(),
    // 목록 탭 화면
    ListTabPage(),
    // 설정 탭 화면
    SettingsTabPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // _index에 맞춰 앱바를 선택
      appBar: _appBars[_index],

      // _index에 맞춰 body를 분기
      body: _pages[_index],

      bottomNavigationBar: BottomNavigationBar(
        onTap: (selected){
          setState(() {
            _index = selected; // 선택된 탭의 인덱스로 _index를 변경
          });
        },
        currentIndex: _index, // 선택된 인덱스
        // 레이블 보이지 않게 하기
        showSelectedLabels: false,
        showUnselectedLabels: false,
        // 아이콘 크기를 일괄 설정
        iconSize: 35.0,  // 기본값은 24.0
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(label: '홈', icon: Icon(Icons.home)),
          BottomNavigationBarItem(label: '목록', icon: Icon(Icons.list)),
          BottomNavigationBarItem(label: '설정', icon: Icon(Icons.settings)),
        ],
      ),
    );
  }
}
