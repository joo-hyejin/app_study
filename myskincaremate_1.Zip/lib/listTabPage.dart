import 'package:flutter/material.dart';

import 'domain/Cosmetic.dart';

class ListTabPage extends StatefulWidget{
  const ListTabPage({Key? key}) : super(key: key);

  @override
  State<ListTabPage> createState() => _ListTabPageState();
}

class _ListTabPageState extends State<ListTabPage>{
  // 상단 필터 항목들
  final List<String> _filterLabels = ['전체', '추천템', '무난템', '비추템'];

  // 현재 선택된 필터 인덱스
  int _selectedFilterIndex = 0;

  // 전체 제품 리스트 (Cosmetic 도메인을 사용한 덤프 데이터, 추후 DB에서 가져온 데이터로 변경하기)
  final List<Cosmetic> _allCosmetics = [
    Cosmetic(brand:'브랜드1', name:'제품명'),
    Cosmetic(brand:'브랜드2', name:'제품명'),
    Cosmetic(brand:'브랜드3', name:'제품명'),
    Cosmetic(brand:'브랜드4', name:'제품명'),
  ];

  @override
  Widget build(BuildContext context) {
    // 선택된 필터에 따른 제품 리스트
    List<Cosmetic> filtered = _allCosmetics.where((c) {
      if(_selectedFilterIndex==0) return true; // 전체 반환
      if(_selectedFilterIndex==1) return c.brand=='브랜드1'; // 추천템
      if(_selectedFilterIndex==2) return c.brand=='브랜드2'; // 무난템
      if(_selectedFilterIndex==3) return c.brand=='브랜드3'; // 비추템
      return true;
    }).toList();

    return Column();
  }

}

