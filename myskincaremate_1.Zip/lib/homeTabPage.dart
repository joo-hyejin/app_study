import 'package:flutter/material.dart';
import 'package:myskincaremate_1/appTheme.dart';

class HomeTabPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      // ListView는 기본적으로 부모의 가로너비 전체 차지
      children: <Widget>[
        _buildTop(),
        _buildMiddle(),
        // _buildBottom(),
      ],
    );
  }

  // 상단
  Widget _buildTop() {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 15.0),
      child: Text(
        '피부 관리를 시작한 지 N일째예요!',
        style: TextStyle(fontSize: 20.0),
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget _buildMiddle() {
    return Container(
      padding: const EdgeInsets.all(15.0),
      margin: const EdgeInsets.symmetric(horizontal: 10.0),
      decoration: BoxDecoration(
        color: AppTheme.c_lightgray,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch, // 가로로 최대
        children: [
          Text(
            '오늘 사용할 제품',
            style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
          ),

          SizedBox(height: 12), // 제목과 카드 사이 여백

          Container(
            padding: EdgeInsets.all(10.0),
            decoration: BoxDecoration(
              border: Border.all(
                color: AppTheme.c_sprout, // 테두리 색
                width: 2.0, // 테두리 두께
              ),
              borderRadius: BorderRadius.circular(20),
              color: Colors.white,
            ),
            child: ListView(
              physics: NeverScrollableScrollPhysics(), // 이 리스트의 스크롤 금지
              shrinkWrap: true, // 이 리스트가 다른 스크롤 객체 안에 있음
              children: _buildListItems(),
            ),
          ),

          SizedBox(height: 12), // 카드와 버튼 사이 여백
          
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () {},
                child: Text('제품 추가', style: TextStyle(fontWeight: FontWeight.bold),),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.c_sprout,
                  foregroundColor: Colors.black,
                ),
              ),
              SizedBox(width: 10.0),
              ElevatedButton(
                onPressed: () {},
                child: Text('사용 체크', style: TextStyle(fontWeight: FontWeight.bold),),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.c_opal,
                  foregroundColor: Colors.black,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // 반복되는 요소(제품 사용 시간대 설정/체크 컴포넌트)
  List<Widget> _buildListItems() {
    final items = List.generate(5, (i) {
      return ListTile(
        contentPadding: EdgeInsets.only(right: 3.0, left: 8.0), // ← 기본 16을 없앰
        isThreeLine: true, // 줄바꿈 허용
        title: Text(
          '브랜드',
          overflow: TextOverflow.ellipsis, // 넘어가면 ... 처리
          style: TextStyle(fontSize: 17.0),
        ),
        subtitle: Text(
          '제품명',
          overflow: TextOverflow.ellipsis,
          style: TextStyle(fontSize: 17.0),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            IconButton(
              onPressed: () {},
              icon: Icon(Icons.sunny),
              style: IconButton.styleFrom(
                backgroundColor: AppTheme.c_sprout.withOpacity(0.5),
              ),
            ),
            IconButton(
              onPressed: () {},
              icon: Icon(Icons.nightlight_round),
              style: IconButton.styleFrom(
                backgroundColor: AppTheme.c_sprout.withOpacity(0.5),
              ),
            ),
          ],
        ),
      );
    });

    return items;
  }
}
