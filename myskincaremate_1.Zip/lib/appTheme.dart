import 'package:flutter/material.dart';


class AppTheme{
  // 앱 전체에서 동일하게 쓸 메인 컬러 정의
  static const Color c_sprout = Color(0xFFCADBAE);
  static const Color c_opal = Color(0xFFB0CCCF);
  static const Color c_roman = Color(0xFFD65A50);
  static const Color c_seawood = Color(0xFF1E3815);
  static const Color c_tomato = Color(0xFFFF3131);
  static const Color c_darkgray = Color(0xFF4F4F4F);
  static const Color c_lightgray = Color(0xFFF5F5F5);
}