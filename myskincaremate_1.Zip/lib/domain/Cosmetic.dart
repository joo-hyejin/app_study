// Cosmetic 도메인 클래스

class Cosmetic {
  int? _cosmeticId;
  String? _brand;
  String? _name;
  String? _category;
  int? _cycleId;
  String? _lastUsedDate;
  int? _usedCount;

  Cosmetic({String? brand, String? name}) {
    this._brand = brand;
    this._name = name;
  }

  // 세터
  String? get brand => _brand;
  String? get name => _name;
}